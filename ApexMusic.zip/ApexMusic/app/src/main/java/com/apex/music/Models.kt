package com.apex.music

import android.content.Context
import androidx.compose.runtime.*
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val uri: String? = null,        // device audio file (playable here)
    val youtubeId: String? = null   // YouTube video (opened in official app/site)
)

data class Playlist(val name: String, val tracks: List<Track>)

// Demo data shown until device/YouTube content is loaded. Not playable.
val sampleTracks = listOf(
    Track("demo1", "Midnight Circuit", "Nova Vale"),
    Track("demo2", "Velvet Static", "The Hollow Keys"),
    Track("demo3", "Red Horizon", "Ada Lune"),
    Track("demo4", "Glass Engine", "Marrow & Vine"),
    Track("demo5", "Afterglow Drive", "Nova Vale")
)

fun Track.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("artist", artist)
    .put("uri", uri ?: "").put("yt", youtubeId ?: "")

fun JSONObject.toTrack() = Track(
    getString("id"), getString("title"), getString("artist"),
    optString("uri").ifEmpty { null }, optString("yt").ifEmpty { null }
)

private fun JSONArray.tracks(): List<Track> = List(length()) { getJSONObject(it).toTrack() }

/** Favorites and playlists, persisted in SharedPreferences as JSON. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("apex", Context.MODE_PRIVATE)

    val favorites = mutableStateListOf<Track>().apply {
        addAll(JSONArray(prefs.getString("fav", "[]")).tracks())
    }

    val playlists = mutableStateListOf<Playlist>().apply {
        val arr = JSONArray(prefs.getString("playlists", "[]"))
        addAll(List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Playlist(o.getString("name"), o.getJSONArray("tracks").tracks())
        })
    }

    fun toggleFavorite(t: Track) {
        val i = favorites.indexOfFirst { it.id == t.id }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, t)
        save()
    }

    fun newPlaylist(name: String) { playlists.add(Playlist(name, emptyList())); save() }

    fun addToPlaylist(index: Int, t: Track) {
        val p = playlists[index]
        if (p.tracks.none { it.id == t.id }) playlists[index] = p.copy(tracks = p.tracks + t)
        save()
    }

    private fun save() {
        prefs.edit()
            .putString("fav", JSONArray(favorites.map { it.toJson() }).toString())
            .putString("playlists", JSONArray(playlists.map { p ->
                JSONObject().put("name", p.name).put("tracks", JSONArray(p.tracks.map { it.toJson() }))
            }).toString())
            .apply()
    }
}

/** Local playback of device audio files via Media3 ExoPlayer. */
class Playback(ctx: Context) {
    private val exo = ExoPlayer.Builder(ctx).build()

    var current by mutableStateOf<Track?>(null)
        private set
    var playing by mutableStateOf(false)
        private set

    init {
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        })
    }

    fun play(t: Track) {
        val uri = t.uri ?: return
        current = t
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.play()
    }

    fun toggle() { if (exo.isPlaying) exo.pause() else exo.play() }

    fun release() = exo.release()
}
