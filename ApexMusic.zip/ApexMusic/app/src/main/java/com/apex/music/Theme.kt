package com.apex.music

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object Apex {
    val Bg = Color(0xFF0A0A0B)
    val Card = Color(0xFF161618)
    val Elevated = Color(0xFF1F1F23)
    val Crimson = Color(0xFFB0121E)
    val Text = Color(0xFFF2F2F3)
    val Muted = Color(0xFF8C8C93)
}

private val scheme = darkColorScheme(
    background = Apex.Bg, surface = Apex.Card, surfaceVariant = Apex.Elevated,
    primary = Apex.Crimson, secondary = Apex.Crimson,
    onBackground = Apex.Text, onSurface = Apex.Text, onSurfaceVariant = Apex.Muted
)

@Composable
fun ApexTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = scheme,
    typography = Typography(
        headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 26.sp, letterSpacing = (-0.5).sp),
        titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp),
        bodyMedium = TextStyle(fontSize = 14.sp)
    ),
    content = content
)
