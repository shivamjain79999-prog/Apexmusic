package com.apex.music

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Official YouTube Data API v3 search. Metadata only; playback happens in YouTube. */
object YouTubeApi {
    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        val key = BuildConfig.YT_API_KEY
        require(key.isNotBlank()) { "Add YT_API_KEY=your_key to local.properties and rebuild." }
        val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
            "&maxResults=25&q=" + URLEncoder.encode(query, "UTF-8") + "&key=" + key
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000; readTimeout = 10_000
        }
        try {
            if (conn.responseCode !in 200..299) error("YouTube returned HTTP ${conn.responseCode}.")
            val items = JSONObject(conn.inputStream.bufferedReader().readText()).getJSONArray("items")
            List(items.length()) { i ->
                val v = items.getJSONObject(i)
                val vid = v.getJSONObject("id").getString("videoId")
                val s = v.getJSONObject("snippet")
                Track(
                    id = "yt_$vid",
                    title = s.getString("title").unescape(),
                    artist = s.getString("channelTitle").unescape(),
                    youtubeId = vid
                )
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun String.unescape() = replace("&amp;", "&").replace("&#39;", "'")
        .replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">")
}
