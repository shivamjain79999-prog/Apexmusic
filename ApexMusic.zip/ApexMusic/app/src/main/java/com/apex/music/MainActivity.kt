package com.apex.music

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ApexTheme { ApexApp() } }
    }
}

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Search("Search", Icons.Filled.Search),
    Library("Library", Icons.Filled.LibraryMusic),
    Playlists("Playlists", Icons.Filled.QueueMusic)
}

@Composable
fun ApexApp() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val playback = remember { Playback(ctx) }
    DisposableEffect(Unit) { onDispose { playback.release() } }

    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var full by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val openTrack: (Track) -> Unit = { t ->
        when {
            t.youtubeId != null -> ctx.startActivity( // official YouTube app, or browser fallback
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${t.youtubeId}")))
            t.uri != null -> playback.play(t)
            else -> scope.launch { snack.showSnackbar("Demo track. Add device music or search YouTube.") }
        }
    }

    Scaffold(
        containerColor = Apex.Bg,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            Column {
                playback.current?.let { t ->
                    MiniPlayer(t, playback.playing, { playback.toggle() }) { full = true }
                }
                NavigationBar(containerColor = Apex.Card) {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t, onClick = { tab = t },
                            icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Apex.Elevated,
                                selectedIconColor = Apex.Crimson, selectedTextColor = Apex.Text)
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                label = "tab"
            ) { t ->
                when (t) {
                    Tab.Home -> HomeScreen(store, openTrack)
                    Tab.Search -> SearchScreen(store, openTrack)
                    Tab.Library -> LibraryScreen(store, openTrack)
                    Tab.Playlists -> PlaylistsScreen(store, openTrack)
                }
            }
            AnimatedVisibility(
                visible = full && playback.current != null,
                enter = slideInVertically { it }, exit = slideOutVertically { it }
            ) {
                playback.current?.let { t ->
                    NowPlaying(t, playback, store) { full = false }
                }
            }
        }
    }
}

@Composable
fun Art(t: Track, size: Dp) {
    val palette = listOf(Color(0xFF6B1A24), Color(0xFF2E2E36), Color(0xFF4A1219), Color(0xFF24242B))
    val c = palette[(t.id.hashCode() and Int.MAX_VALUE) % palette.size]
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(c, Apex.Card))),
        contentAlignment = Alignment.Center
    ) {
        Text(t.title.take(1).uppercase(), color = Apex.Text.copy(alpha = 0.7f), fontSize = (size.value / 3).sp)
    }
}

@Composable
fun SectionTitle(s: String) =
    Text(s.uppercase(), color = Apex.Crimson, style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 12.dp))

@Composable
fun ArtCard(t: Track, onClick: () -> Unit) {
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Art(t, 150.dp)
        Spacer(Modifier.height(8.dp))
        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Apex.Text)
        Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Apex.Muted,
            style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun TrackRow(t: Track, store: Store, onPlay: () -> Unit) {
    val fav = store.favorites.any { it.id == t.id }
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onPlay)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(t, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Apex.Text)
            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Apex.Muted,
                style = MaterialTheme.typography.bodyMedium)
        }
        IconButton(onClick = { store.toggleFavorite(t) }) {
            Icon(if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite",
                tint = if (fav) Apex.Crimson else Apex.Muted)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More", tint = Apex.Muted) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false },
                modifier = Modifier.background(Apex.Elevated)) {
                if (store.playlists.isEmpty())
                    DropdownMenuItem(text = { Text("No playlists yet") }, onClick = { menu = false })
                store.playlists.forEachIndexed { i, p ->
                    DropdownMenuItem(text = { Text("Add to ${p.name}") },
                        onClick = { store.addToPlaylist(i, t); menu = false })
                }
            }
        }
    }
}

@Composable
fun EmptyState(msg: String, action: (() -> Unit)? = null) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(msg, color = Apex.Muted, textAlign = TextAlign.Center)
            if (action != null) TextButton(onClick = action) { Text("Grant access", color = Apex.Crimson) }
        }
    }
}

@Composable
fun HomeScreen(store: Store, onPlay: (Track) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("APEX MUSIC", style = MaterialTheme.typography.headlineMedium, color = Apex.Text) }
        item { SectionTitle("Featured") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(sampleTracks) { t -> ArtCard(t) { onPlay(t) } }
            }
        }
        item { SectionTitle("Favorites") }
        if (store.favorites.isEmpty()) item {
            Text("Tap the heart on any track to save it here.", color = Apex.Muted)
        }
        items(store.favorites, key = { it.id }) { t -> TrackRow(t, store) { onPlay(t) } }
    }
}

@Composable
fun SearchScreen(store: Store, onPlay: (Track) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun search() {
        if (q.isBlank()) return
        loading = true; error = null
        scope.launch {
            runCatching { YouTubeApi.search(q.trim()) }
                .onSuccess { results = it }
                .onFailure { error = it.message ?: "Search failed. Check your connection." }
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Search YouTube", style = MaterialTheme.typography.headlineMedium, color = Apex.Text)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, shape = RoundedCornerShape(16.dp),
            placeholder = { Text("Songs, artists, videos", color = Apex.Muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { search() })
        )
        Spacer(Modifier.height(12.dp))
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Apex.Crimson)
            }
            error != null -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!, color = Apex.Muted, textAlign = TextAlign.Center)
                TextButton(onClick = { search() }) { Text("Retry", color = Apex.Crimson) }
            }
            results.isEmpty() -> EmptyState("Search for songs, artists or videos.")
            else -> LazyColumn {
                items(results, key = { it.id }) { t -> TrackRow(t, store) { onPlay(t) } }
            }
        }
    }
}

fun audioPermission() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

fun hasAudioPermission(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, audioPermission()) == PackageManager.PERMISSION_GRANTED

fun loadDeviceTracks(ctx: Context): List<Track> {
    val out = mutableListOf<Track>()
    val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            out += Track(
                id = "local_$id",
                title = c.getString(1) ?: "Unknown title",
                artist = c.getString(2) ?: "Unknown artist",
                uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id).toString()
            )
        }
    }
    return out
}

@Composable
fun LibraryScreen(store: Store, onPlay: (Track) -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(ctx)) }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    LaunchedEffect(granted) {
        if (granted) tracks = withContext(Dispatchers.IO) { loadDeviceTracks(ctx) }
        else launcher.launch(audioPermission())
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Library", style = MaterialTheme.typography.headlineMedium, color = Apex.Text)
        Text("On this device", color = Apex.Muted)
        Spacer(Modifier.height(12.dp))
        when {
            !granted -> EmptyState("Allow audio access to see music on this phone.") { launcher.launch(audioPermission()) }
            tracks.isEmpty() -> EmptyState("No music files found on this device.")
            else -> LazyColumn { items(tracks, key = { it.id }) { t -> TrackRow(t, store) { onPlay(t) } } }
        }
    }
}

@Composable
fun PlaylistsScreen(store: Store, onPlay: (Track) -> Unit) {
    var creating by remember { mutableStateOf(false) }
    var open by rememberSaveable { mutableStateOf(-1) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Playlists", style = MaterialTheme.typography.headlineMedium, color = Apex.Text,
                modifier = Modifier.weight(1f))
            IconButton(onClick = { creating = true }) {
                Icon(Icons.Filled.Add, "New playlist", tint = Apex.Crimson)
            }
        }
        if (store.playlists.isEmpty()) {
            EmptyState("Create a playlist, then add songs from any track's menu.")
        } else LazyColumn {
            itemsIndexed(store.playlists) { i, p ->
                Column(Modifier.fillMaxWidth().clickable { open = if (open == i) -1 else i }.padding(vertical = 12.dp)) {
                    Text(p.name, color = Apex.Text, style = MaterialTheme.typography.titleMedium)
                    Text("${p.tracks.size} tracks", color = Apex.Muted)
                    AnimatedVisibility(visible = open == i) {
                        Column {
                            if (p.tracks.isEmpty()) Text("Empty. Add tracks from any list.", color = Apex.Muted)
                            p.tracks.forEach { t -> TrackRow(t, store) { onPlay(t) } }
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { creating = false },
            containerColor = Apex.Elevated,
            title = { Text("New playlist") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(),
                    onClick = { store.newPlaylist(name.trim()); creating = false }) {
                    Text("Create", color = Apex.Crimson)
                }
            },
            dismissButton = { TextButton(onClick = { creating = false }) { Text("Cancel", color = Apex.Muted) } }
        )
    }
}

@Composable
fun MiniPlayer(t: Track, playing: Boolean, onToggle: () -> Unit, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp)).background(Apex.Elevated)
            .clickable(onClick = onOpen).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(t, 40.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Apex.Text)
            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Apex.Muted,
                style = MaterialTheme.typography.bodyMedium)
        }
        IconButton(onClick = onToggle) {
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play or pause", tint = Apex.Text)
        }
    }
}

@Composable
fun NowPlaying(t: Track, playback: Playback, store: Store, onClose: () -> Unit) {
    val fav = store.favorites.any { it.id == t.id }
    Column(
        Modifier.fillMaxSize().background(Apex.Bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") }
            Text("Now playing", color = Apex.Muted, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.weight(0.5f))
        Art(t, 280.dp)
        Spacer(Modifier.height(32.dp))
        Text(t.title, style = MaterialTheme.typography.headlineMedium, color = Apex.Text,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(t.artist, color = Apex.Muted)
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { store.toggleFavorite(t) }) {
                Icon(if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite",
                    tint = if (fav) Apex.Crimson else Apex.Muted)
            }
            FilledIconButton(
                onClick = { playback.toggle() },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Apex.Crimson),
                modifier = Modifier.size(72.dp)
            ) {
                Icon(if (playback.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    "Play or pause", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { store.addToPlaylist(0, t) }, enabled = store.playlists.isNotEmpty()) {
                Icon(Icons.Filled.QueueMusic, "Add to first playlist", tint = Apex.Muted)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
